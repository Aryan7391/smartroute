import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform, Linking } from 'react-native';
import MapView, { Marker, Polyline, Callout } from 'react-native-maps';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { useRoute } from '../context/RouteContext';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';
import { getStopLabel, getStopColor, getStopAddress, decodeGeoJSONLineString } from '../utils/helpers';

export default function MapScreen() {
  const { stops, vehicle, segments, remainingStops, fetchSegments } = useRoute();
  const [userLocation, setUserLocation] = useState(null);
  const mapRef = useRef(null);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({});
        setUserLocation({
          latitude: loc.coords.latitude,
          longitude: loc.coords.longitude,
        });
      }
    })();
  }, []);

  useEffect(() => {
    if (vehicle?.id) {
      fetchSegments(vehicle.id);
    }
  }, [vehicle?.id]);

  const fitToMarkers = () => {
    if (!mapRef.current) return;
    const coordinates = stops
      .filter((s) => !s.is_done)
      .map((s) => ({ latitude: s.lat, longitude: s.lng }));

    if (userLocation) coordinates.push(userLocation);
    if (vehicle?.current_lat) {
      coordinates.push({ latitude: vehicle.current_lat, longitude: vehicle.current_lng });
    }

    if (coordinates.length > 0) {
      mapRef.current.fitToCoordinates(coordinates, {
        edgePadding: { top: 80, right: 60, bottom: 80, left: 60 },
        animated: true,
      });
    }
  };

  const openInMaps = (lat, lng, address) => {
    const label = encodeURIComponent(address || 'Stop');
    const url = Platform.select({
      ios: `maps:0,0?q=${label}@${lat},${lng}`,
      android: `geo:${lat},${lng}?q=${lat},${lng}(${label})`,
    });
    Linking.openURL(url);
  };

  // Compute initial region
  const initialRegion = vehicle?.current_lat
    ? {
        latitude: vehicle.current_lat,
        longitude: vehicle.current_lng,
        latitudeDelta: 0.1,
        longitudeDelta: 0.1,
      }
    : userLocation
    ? {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.1,
        longitudeDelta: 0.1,
      }
    : {
        latitude: 28.6139, // Default: Delhi
        longitude: 77.2090,
        latitudeDelta: 0.2,
        longitudeDelta: 0.2,
      };

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={initialRegion}
        showsUserLocation
        showsMyLocationButton={false}
        onMapReady={fitToMarkers}
      >
        {/* Vehicle marker */}
        {vehicle?.current_lat && (
          <Marker
            coordinate={{
              latitude: vehicle.current_lat,
              longitude: vehicle.current_lng,
            }}
            title="Your Vehicle"
            anchor={{ x: 0.5, y: 0.5 }}
          >
            <View style={styles.vehicleMarker}>
              <MaterialCommunityIcons name="truck" size={20} color={colors.textOnPrimary} />
            </View>
          </Marker>
        )}

        {/* Stop markers */}
        {stops.map((stop) => {
          const isDone = stop.is_done;
          const stopColor = isDone ? colors.textLight : getStopColor(stop.type);
          const label = getStopLabel(stop.type);
          const address = getStopAddress(stop);

          return (
            <Marker
              key={stop.id}
              coordinate={{ latitude: stop.lat, longitude: stop.lng }}
              title={`#${stop.sequence} ${label}`}
              description={address}
              pinColor={stopColor}
            >
              <View style={[styles.stopMarker, { backgroundColor: stopColor }]}>
                <Text style={styles.stopMarkerText}>{stop.sequence}</Text>
              </View>
              <Callout
                onPress={() => openInMaps(stop.lat, stop.lng, address)}
                style={styles.callout}
              >
                <View style={styles.calloutContent}>
                  <Text style={styles.calloutTitle}>
                    #{stop.sequence} {label}
                  </Text>
                  <Text style={styles.calloutAddress} numberOfLines={2}>
                    {address}
                  </Text>
                  <Text style={styles.calloutAction}>Tap to navigate →</Text>
                </View>
              </Callout>
            </Marker>
          );
        })}

        {/* Route polylines from segments */}
        {segments.map((seg, index) => {
          const coords = decodeGeoJSONLineString(seg.geometry);
          if (coords.length < 2) return null;
          return (
            <Polyline
              key={`seg-${index}`}
              coordinates={coords}
              strokeWidth={seg.is_done ? 3 : 5}
              strokeColor={seg.is_done ? colors.textLight : colors.primary}
              lineDashPattern={seg.is_done ? [10, 5] : null}
            />
          );
        })}
      </MapView>

      {/* Fit to markers button */}
      <TouchableOpacity style={styles.fitButton} onPress={fitToMarkers}>
        <MaterialCommunityIcons name="fit-to-screen" size={22} color={colors.text} />
      </TouchableOpacity>

      {/* Legend */}
      <View style={styles.legend}>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: colors.pickup }]} />
          <Text style={styles.legendText}>Pickup</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: colors.delivery }]} />
          <Text style={styles.legendText}>Delivery</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: colors.textLight }]} />
          <Text style={styles.legendText}>Done</Text>
        </View>
      </View>

      {/* Stop count overlay */}
      <View style={styles.stopCountOverlay}>
        <Text style={styles.stopCountText}>
          {remainingStops.length} stops remaining
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  vehicleMarker: {
    backgroundColor: colors.primary,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: colors.textOnPrimary,
    ...shadows.md,
  },
  stopMarker: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.textOnPrimary,
    ...shadows.sm,
  },
  stopMarkerText: {
    fontFamily: typography.fontFamilyBold,
    fontSize: 11,
    color: colors.textOnPrimary,
  },
  callout: {
    width: 220,
  },
  calloutContent: {
    padding: spacing.sm,
  },
  calloutTitle: {
    fontFamily: typography.fontFamilySemiBold,
    fontSize: typography.sm,
    color: colors.text,
  },
  calloutAddress: {
    fontFamily: typography.fontFamily,
    fontSize: typography.xs,
    color: colors.textMuted,
    marginTop: 2,
  },
  calloutAction: {
    fontFamily: typography.fontFamilySemiBold,
    fontSize: typography.xs,
    color: colors.primary,
    marginTop: spacing.xs,
  },
  fitButton: {
    position: 'absolute',
    top: 60,
    right: spacing.md,
    backgroundColor: colors.surface,
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.md,
  },
  legend: {
    position: 'absolute',
    bottom: spacing.lg,
    left: spacing.md,
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.sm,
    paddingHorizontal: spacing.md,
    gap: spacing.md,
    ...shadows.md,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontFamily: typography.fontFamilyMedium,
    fontSize: typography.xs,
    color: colors.textSecondary,
  },
  stopCountOverlay: {
    position: 'absolute',
    top: 60,
    left: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    ...shadows.md,
  },
  stopCountText: {
    fontFamily: typography.fontFamilySemiBold,
    fontSize: typography.sm,
    color: colors.text,
  },
});
